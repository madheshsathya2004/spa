import React, { useEffect, useState } from 'react'
import BookingCard from '../components/BookingCard'

export default function BookingsPage(){
  const [bookings, setBookings] = useState([])
  const [filter, setFilter] = useState('ALL')

  useEffect(()=>{
    fetch('http://localhost:5000/api/bookings/101').then(r=>r.json()).then(data=>{
      // map add serviceName for demo if not present
      const mapped = (data||[]).map(b => ({ ...b, serviceName: b.serviceName || 'Aroma Massage' }))
      setBookings(mapped)
    }).catch(()=>{})
  },[])

  const act = async (id, status) => {
    await fetch(`http://localhost:5000/api/bookings/update/${id}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ status }) })
    setBookings(prev=>prev.map(b=>b.id===id?{...b,status}:b))
  }

  const shown = filter === 'ALL' ? bookings : bookings.filter(b => b.status === filter)

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4>Bookings</h4>
        <div className="btn-group">
          <button className={`btn btn-sm ${filter==='ALL' ? 'btn-accent' : 'btn-outline-light'}`} onClick={()=>setFilter('ALL')}>All</button>
          <button className={`btn btn-sm ${filter==='PENDING' ? 'btn-accent' : 'btn-outline-light'}`} onClick={()=>setFilter('PENDING')}>Pending</button>
          <button className={`btn btn-sm ${filter==='CONFIRMED' ? 'btn-accent' : 'btn-outline-light'}`} onClick={()=>setFilter('CONFIRMED')}>Confirmed</button>
          <button className={`btn btn-sm ${filter==='DECLINED' ? 'btn-accent' : 'btn-outline-light'}`} onClick={()=>setFilter('DECLINED')}>Declined</button>
        </div>
      </div>

      <div className="d-grid gap-3">
        {shown.map(b => <BookingCard key={b.id} booking={b} onAction={act} />)}
      </div>
    </>
  )
}
