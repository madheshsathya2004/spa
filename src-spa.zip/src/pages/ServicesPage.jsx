import React, { useEffect, useState } from 'react'
import ServiceCard from '../components/ServiceCard'

export default function ServicesPage(){
  const [services, setServices] = useState([])
  const [form, setForm] = useState({ name:'Aroma Massage', price:500, duration:45, image:'/services/service1.jpg' })

  useEffect(()=>{
    fetch('http://localhost:5000/api/services/101').then(r=>r.json()).then(setServices).catch(()=>{})
  },[])

  const add = async ()=>{
    const payload = { spaId:'101', ...form }
    const res = await fetch('http://localhost:5000/api/services/add',{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) })
    const data = await res.json()
    setServices(prev=>[data, ...prev])
  }

  const toggle = async (id)=>{
    const svc = services.find(s=>s.id===id)
    const newStatus = svc.status === 'Available' ? 'Unavailable' : 'Available'
    await fetch(`http://localhost:5000/api/services/status/${id}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ status: newStatus }) })
    setServices(prev=>prev.map(s=>s.id===id?{...s, status:newStatus}:s))
  }

  return (
    <div className="row">
      <div className="col-12 col-lg-8">
        <div className="card card-dark p-4 rounded-4 mb-4">
          <h5 className="mb-3">Create Service</h5>
          <div className="d-flex gap-2">
            <input className="form-control bg-transparent text-light" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
            <input className="form-control w-25 bg-transparent text-light" value={form.price} onChange={e=>setForm({...form, price:e.target.value})} />
            <button className="btn btn-accent" onClick={add}>Add</button>
          </div>
        </div>

        <div className="d-grid gap-3">
          {services.map(svc=> <ServiceCard key={svc.id} svc={svc} onToggle={toggle} />)}
        </div>
      </div>

      <div className="col-12 col-lg-4">
        <div className="card card-dark p-4 rounded-4">
          <h6>Pro Tip</h6>
          <p className="small text-muted">Set accurate durations and prices to reduce booking friction.</p>
        </div>
      </div>
    </div>
  )
}
