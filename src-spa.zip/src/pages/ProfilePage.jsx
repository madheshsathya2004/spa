import React, { useState } from 'react'

export default function ProfilePage({ user, setUser }) {
  const [form, setForm] = useState(user || { id:'1', name:'Client User', email:'client@gmail.com' })
  const [saved, setSaved] = useState(false)

  const save = () => {
    localStorage.setItem('spa_user', JSON.stringify(form))
    setUser && setUser(form)
    setSaved(true)
    setTimeout(()=>setSaved(false), 2000)
  }

  return (
    <div className="card card-dark p-4 rounded-4">
      <h4>Profile</h4>
      <label className="form-label small text-muted mt-3">Name</label>
      <input className="form-control bg-transparent text-light" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />

      <label className="form-label small text-muted mt-3">Email</label>
      <input className="form-control bg-transparent text-light" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} />

      <div className="mt-3">
        <button className="btn btn-accent" onClick={save}>Save</button>
        {saved && <span className="text-success ms-3">Saved</span>}
      </div>
    </div>
  )
}
