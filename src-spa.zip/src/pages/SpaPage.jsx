import React, { useEffect, useState } from 'react'

export default function SpaPage({ user }) {
  const [form, setForm] = useState({ name:'Tranquility Spa', address:'City Center', description:'Holistic treatments to restore balance', images: ['/spa1.jpg','/spa2.jpg'] })
  const [saved, setSaved] = useState(false)

  useEffect(()=>{
    // Optionally load existing spa
    const clientId = user?.id || '1'
    fetch(`http://localhost:5000/api/spas/${clientId}`).then(r=>r.json()).then(data=>{
      if(Array.isArray(data) && data.length) setForm(data[0])
    }).catch(()=>{})
  }, [user])

  const handleSave = async () => {
    const payload = { clientId: user?.id || '1', ...form, status: 'PENDING' }
    await fetch('http://localhost:5000/api/spas/add', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) })
    setSaved(true)
    setTimeout(()=>setSaved(false), 2000)
  }

  return (
    <div className="row g-4">
      <div className="col-12 col-lg-8">
        <div className="card card-dark p-4 rounded-4">
          <h4 className="mb-3">Edit Spa</h4>
          <label className="form-label small text-muted">Name</label>
          <input className="form-control mb-3 bg-transparent text-light" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />

          <label className="form-label small text-muted">Address</label>
          <input className="form-control mb-3 bg-transparent text-light" value={form.address} onChange={e=>setForm({...form, address:e.target.value})} />

          <label className="form-label small text-muted">Description</label>
          <textarea className="form-control mb-3 bg-transparent text-light" rows="4" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} />

          <div className="d-flex gap-2">
            <button className="btn btn-accent" onClick={handleSave}>Save Spa</button>
            {saved && <div className="align-self-center text-success">Saved</div>}
          </div>
        </div>
      </div>

      <div className="col-12 col-lg-4">
        <div className="card card-dark p-3 rounded-4">
          <h6 className="fw-semibold">Preview</h6>
          <img src={form.images?.[0]} alt="preview" className="img-fluid rounded-3 mt-3" />
          <h5 className="mt-3">{form.name}</h5>
          <p className="small text-muted">{form.address}</p>
          <p className="text-muted">{form.description}</p>
        </div>
      </div>
    </div>
  )
}
