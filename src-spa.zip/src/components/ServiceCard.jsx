import React from 'react'

export default function ServiceCard({ svc, onToggle }) {
  return (
    <div className="card card-dark p-3 rounded-4 d-flex align-items-center">
      <div className="d-flex align-items-center w-100">
        <img src={svc.image || '/services/service1.jpg'} alt="" className="rounded-3 me-3" style={{width:84, height:64, objectFit:'cover'}} />
        <div className="flex-grow-1">
          <div className="fw-semibold">{svc.name}</div>
          <div className="small text-muted">{svc.duration} min • ₹{svc.price}</div>
        </div>
        <div>
          <button className={`btn btn-sm ${svc.status === 'Available' ? 'btn-success' : 'btn-secondary'}`} onClick={()=>onToggle && onToggle(svc.id)}>
            {svc.status}
          </button>
        </div>
      </div>
    </div>
  )
}
