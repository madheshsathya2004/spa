import React from 'react'

export default function BookingCard({ booking, onAction }) {
  return (
    <div className="card card-dark p-3 rounded-4 d-flex justify-content-between align-items-start">
      <div>
        <div className="fw-semibold">{booking.userName || 'Guest'}</div>
        <div className="small text-muted">{booking.date}</div>
        <div className="mt-2">{booking.serviceName || 'Service'}</div>
      </div>

      <div className="text-end">
        <div className={`badge rounded-pill px-3 py-2 ${booking.status === 'PENDING' ? 'text-dark' : 'bg-transparent'}`} style={{ background: booking.status==='PENDING' ? 'linear-gradient(90deg,var(--accent), var(--gold))' : booking.status==='CONFIRMED' ? 'linear-gradient(90deg,#10b981,#34d399)' : 'linear-gradient(90deg,#ef4444,#f97316)'}}>
          {booking.status}
        </div>
        {booking.status === 'PENDING' && (
          <div className="mt-2 d-flex gap-2">
            <button className="btn btn-sm btn-success" onClick={()=>onAction && onAction(booking.id,'CONFIRMED')}>Confirm</button>
            <button className="btn btn-sm btn-danger" onClick={()=>onAction && onAction(booking.id,'DECLINED')}>Decline</button>
          </div>
        )}
      </div>
    </div>
  )
}
