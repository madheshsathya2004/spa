import React from 'react'

export default function SpaCard({ spa }) {
  if(!spa) return (
    <div className="card card-dark p-4 rounded-4">
      <div className="card-body">
        <h5 className="card-title">No spa yet</h5>
        <p className="text-muted">Add your spa to get started.</p>
      </div>
    </div>
  )

  return (
    <div className="card card-dark rounded-4 overflow-hidden">
      <div className="row g-0">
        <div className="col-md-6 img-overlay">
          <img src={spa.images?.[0] || '/spa1.jpg'} alt="spa" className="img-fluid h-100 w-100" style={{objectFit:'cover'}} />
        </div>
        <div className="col-md-6 p-4 d-flex flex-column justify-content-between">
          <div>
            <h5 className="fw-bold">{spa.name}</h5>
            <p className="text-muted mb-2 small">{spa.address}</p>
            <p className="mb-0">{spa.description}</p>
          </div>
          <div className="d-flex justify-content-between align-items-center mt-3">
            <span className="badge badge-pulse rounded-pill px-3 py-2">{spa.status}</span>
            <div className="small text-muted">Updated recently</div>
          </div>
        </div>
      </div>
    </div>
  )
}
