// small wrapper using fetch (no axios required)
const BASE = 'http://localhost:5000/api';

async function api(path, options = {}) {
  const res = await fetch(BASE + path, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || res.statusText);
  }
  return res.json();
}

export default {
  login: (payload) => api('/auth/login', { method: 'POST', body: JSON.stringify(payload) }),
  getSpasByClient: (clientId) => api(`/spas/${clientId}`),
  addSpa: (payload) => api('/spas/add', { method: 'POST', body: JSON.stringify(payload) }),
  getServicesBySpa: (spaId) => api(`/services/${spaId}`),
  addService: (payload) => api('/services/add', { method: 'POST', body: JSON.stringify(payload) }),
  updateServiceStatus: (id, payload) => api(`/services/status/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  getBookingsBySpa: (spaId) => api(`/bookings/${spaId}`),
  updateBooking: (id, payload) => api(`/bookings/update/${id}`, { method: 'PUT', body: JSON.stringify(payload) })
};
