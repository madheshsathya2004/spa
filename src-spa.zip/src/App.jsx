import React, { useEffect, useState } from 'react'
import { Routes, Route, useNavigate } from 'react-router-dom'
import Navbar from './components/Navbar'
import Dashboard from './pages/Dashboard'
import SpaPage from './pages/SpaPage'
import ServicesPage from './pages/ServicesPage'
import BookingsPage from './pages/BookingsPage'
import ProfilePage from './pages/ProfilePage'

export default function App(){
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem('spa_user');
    return raw ? JSON.parse(raw) : null;
  })
  const navigate = useNavigate()

  useEffect(()=> {
    if(!user) {
      // Provide a demo user by default for easy testing
      const demo = { id: '1', name: 'Client User', email: 'client@gmail.com' }
      localStorage.setItem('spa_user', JSON.stringify(demo))
      setUser(demo)
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem('spa_user')
    setUser(null)
    navigate('/')
  }

  return (
    <>
      <Navbar user={user} onLogout={handleLogout} />
      <div className="container-xl py-5 page-fade">
        <Routes>
          <Route path="/" element={<Dashboard user={user} />} />
          <Route path="/spa" element={<SpaPage user={user} />} />
          <Route path="/services" element={<ServicesPage user={user} />} />
          <Route path="/bookings" element={<BookingsPage user={user} />} />
          <Route path="/profile" element={<ProfilePage user={user} setUser={setUser} />} />
        </Routes>
      </div>
    </>
  )
}
